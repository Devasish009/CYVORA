# TravelBharat – Explore India State by State

> **Internship Project** | Unified Mentor × Incredible India  
> A centralized tourism information platform providing state-wise and city-wise details of tourist destinations across India.

---

## Executive Summary

TravelBharat will be a full-stack tourism web application with a **vanilla HTML/CSS/JS frontend** (styled with **Tailwind CSS**), **Node.js/Express.js backend** with **EJS templating**, and **PostgreSQL database**. The platform lets users explore India's 28 states and 8 union territories, discover tourist destinations by category, and view rich destination pages with images, descriptions, and travel information.

The project is a **single Express.js application** that serves both the rendered HTML pages and the REST API. This architecture keeps things simple while delivering a professional, full-stack product.

## ✅ Finalized Stack

| Layer | Technology |
|-------|-----------|
| **Frontend** | HTML5 + EJS Templates + Vanilla JavaScript |
| **Styling** | Tailwind CSS (CDN) |
| **Backend** | Node.js + Express.js |
| **Database** | PostgreSQL + Sequelize ORM |
| **Images** | Unsplash (seed) + Cloudinary (admin uploads) |
| **Auth** | JWT + bcrypt |
| **Deployment** | Render / Railway (free tier) |

```mermaid
graph TB
    subgraph "Browser - Client Side"
        A[HTML Pages with Tailwind CSS]
        B[Client-Side JavaScript]
        B --> |fetch API calls| C[Dynamic Interactions]
    end

    subgraph "Server - Express.js + EJS"
        D[Express.js Server]
        E[EJS Template Engine]
        F[REST API Routes /api/*]
        G[Page Routes / ]
        H[Auth Middleware - JWT]
        I[Multer + Cloudinary - Image Upload]
        D --> E
        D --> F
        D --> G
        D --> H
        D --> I
    end

    subgraph "Database - PostgreSQL"
        J[(States Table)]
        K[(Cities Table)]
        L[(Destinations Table)]
        M[(Categories Table)]
        N[(Admin Users Table)]
        O[(Destination Images Table)]
    end

    A --> D
    B --> F
    G --> E --> A
    F --> J & K & L & M & N & O
```

### Why EJS + Express (not pure static HTML)?

A tourism site needs **dynamic pages** — you can't manually create an HTML file for each of 100+ destinations. **EJS templates** let you write HTML (exactly like regular HTML) but inject data from PostgreSQL dynamically. This means:
- ✅ You write HTML, CSS, JS — exactly as requested
- ✅ Pages are server-rendered = great for SEO
- ✅ One template generates hundreds of destination pages
- ✅ Single project = simpler deployment

---

## Technology Stack

| Layer | Technology | Purpose |
|-------|-----------|---------|
| **Frontend** | HTML5 + EJS Templates | Page structure & dynamic rendering |
| **Styling** | Tailwind CSS (CDN/CLI) | Responsive, utility-first styling |
| **Interactivity** | Vanilla JavaScript | Animations, search, filters, fetch API |
| **Backend** | Node.js + Express.js | Server, routing, API |
| **Database** | PostgreSQL | Relational data storage |
| **ORM** | Sequelize | Database queries & migrations |
| **Auth** | JWT + bcrypt | Admin authentication |
| **Images** | Cloudinary (free tier) | Image hosting & optimization |
| **Deployment** | Render / Railway | Full-stack hosting (free tier) |

---

## Project Structure

```
TravelBharat/
├── public/                          # Static assets (served by Express)
│   ├── css/
│   │   └── styles.css               # Tailwind output + custom styles
│   ├── js/
│   │   ├── main.js                  # Global scripts (navbar, animations)
│   │   ├── search.js                # Search & autocomplete logic
│   │   ├── map.js                   # Interactive India map
│   │   ├── gallery.js               # Image gallery lightbox
│   │   ├── filters.js               # Category/region filter logic
│   │   ├── admin.js                 # Admin panel interactions
│   │   └── animations.js            # Scroll reveals, counters, effects
│   ├── images/
│   │   ├── hero/                    # Hero section backgrounds
│   │   ├── icons/                   # Category & UI icons
│   │   ├── logo/                    # TravelBharat logo
│   │   └── og/                      # Open Graph images
│   └── india-map.svg                # Interactive SVG map of India
│
├── views/                           # EJS templates (HTML with data injection)
│   ├── layouts/
│   │   ├── main.ejs                 # Base layout (head, nav, footer)
│   │   └── admin.ejs                # Admin layout (sidebar, header)
│   ├── partials/
│   │   ├── navbar.ejs               # Navigation bar
│   │   ├── footer.ejs               # Footer
│   │   ├── hero.ejs                 # Hero section
│   │   ├── state-card.ejs           # State grid card
│   │   ├── dest-card.ejs            # Destination card
│   │   ├── search-bar.ejs           # Global search component
│   │   ├── breadcrumb.ejs           # Breadcrumb navigation
│   │   ├── category-badge.ejs       # Category tag badge
│   │   ├── pagination.ejs           # Pagination component
│   │   ├── image-carousel.ejs       # Image carousel/slider
│   │   └── stats-counter.ejs        # Animated statistics
│   ├── pages/
│   │   ├── home.ejs                 # Landing page
│   │   ├── states.ejs               # All states listing
│   │   ├── state-detail.ejs         # Single state page
│   │   ├── destination-detail.ejs   # Single destination page
│   │   ├── explore.ejs              # Search & discovery page
│   │   ├── categories.ejs           # Categories page
│   │   ├── category-detail.ejs      # Destinations by category
│   │   ├── gallery.ejs              # Photo gallery page
│   │   ├── about.ejs                # About TravelBharat
│   │   └── 404.ejs                  # Not found page
│   └── admin/
│       ├── login.ejs                # Admin login
│       ├── dashboard.ejs            # Admin dashboard
│       ├── states.ejs               # Manage states (CRUD table)
│       ├── state-form.ejs           # Add/Edit state form
│       ├── destinations.ejs         # Manage destinations
│       ├── destination-form.ejs     # Add/Edit destination form
│       └── categories.ejs           # Manage categories
│
├── src/                             # Server-side source code
│   ├── config/
│   │   ├── database.js              # PostgreSQL + Sequelize setup
│   │   ├── cloudinary.js            # Cloudinary configuration
│   │   └── constants.js             # App-wide constants
│   ├── models/
│   │   ├── index.js                 # Model associations & sync
│   │   ├── State.js                 # State model
│   │   ├── City.js                  # City model
│   │   ├── Destination.js           # Destination model
│   │   ├── Category.js              # Category model
│   │   ├── DestinationImage.js      # Destination images model
│   │   ├── DestinationCategory.js   # Junction table
│   │   └── Admin.js                 # Admin user model
│   ├── routes/
│   │   ├── pageRoutes.js            # HTML page routes (GET /)
│   │   ├── apiStateRoutes.js        # API: /api/states
│   │   ├── apiDestRoutes.js         # API: /api/destinations
│   │   ├── apiCategoryRoutes.js     # API: /api/categories
│   │   ├── apiSearchRoutes.js       # API: /api/search
│   │   ├── apiAuthRoutes.js         # API: /api/auth
│   │   ├── apiUploadRoutes.js       # API: /api/upload
│   │   └── adminRoutes.js           # Admin page routes
│   ├── controllers/
│   │   ├── pageController.js        # Render HTML pages
│   │   ├── stateController.js       # State CRUD logic
│   │   ├── destinationController.js # Destination CRUD logic
│   │   ├── categoryController.js    # Category CRUD logic
│   │   ├── searchController.js      # Search logic
│   │   ├── authController.js        # Login/logout logic
│   │   └── uploadController.js      # Image upload logic
│   ├── middleware/
│   │   ├── auth.js                  # JWT verification
│   │   ├── errorHandler.js          # Global error handler
│   │   └── upload.js                # Multer file upload config
│   ├── seed/
│   │   ├── data/
│   │   │   ├── states.json          # All 36 states/UTs data
│   │   │   ├── cities.json          # 60+ cities data
│   │   │   ├── destinations.json    # 100+ destinations data
│   │   │   └── categories.json      # 4 categories data
│   │   └── seed.js                  # Database seeder script
│   └── utils/
│       ├── helpers.js               # Slug generation, formatting
│       └── validators.js            # Input validation functions
│
├── tailwind.config.js               # Tailwind CSS configuration
├── package.json                     # Dependencies & scripts
├── server.js                        # Express app entry point
├── .env.example                     # Environment variables template
├── .gitignore
└── README.md                        # Project documentation
```

---

## Database Schema (PostgreSQL)

### ER Diagram

```mermaid
erDiagram
    STATES ||--o{ CITIES : has
    STATES ||--o{ DESTINATIONS : has
    CITIES ||--o{ DESTINATIONS : has
    DESTINATIONS }o--o{ CATEGORIES : belongs_to
    DESTINATIONS ||--o{ DESTINATION_IMAGES : has

    STATES {
        int id PK
        varchar name
        varchar slug UK
        varchar capital
        varchar region
        varchar type
        text description
        text highlights
        varchar hero_image
        varchar thumbnail
        varchar best_time_to_visit
        varchar languages
        boolean is_active
        timestamp created_at
        timestamp updated_at
    }

    CITIES {
        int id PK
        varchar name
        varchar slug UK
        int state_id FK
        text description
        boolean is_active
        timestamp created_at
        timestamp updated_at
    }

    DESTINATIONS {
        int id PK
        varchar name
        varchar slug UK
        int state_id FK
        int city_id FK
        text description
        text historical_significance
        varchar best_time_to_visit
        varchar entry_fee
        varchar timings
        varchar address
        varchar map_link
        decimal latitude
        decimal longitude
        varchar tags
        boolean is_featured
        boolean is_active
        timestamp created_at
        timestamp updated_at
    }

    CATEGORIES {
        int id PK
        varchar name
        varchar slug UK
        text description
        varchar icon
        varchar color
        boolean is_active
        timestamp created_at
        timestamp updated_at
    }

    DESTINATION_CATEGORIES {
        int destination_id FK
        int category_id FK
    }

    DESTINATION_IMAGES {
        int id PK
        int destination_id FK
        varchar url
        varchar caption
        boolean is_primary
        timestamp created_at
    }

    ADMINS {
        int id PK
        varchar username UK
        varchar email UK
        varchar password_hash
        varchar full_name
        timestamp last_login
        boolean is_active
        timestamp created_at
    }
```

---

## UI/UX Design Plan

### Design System

| Token            | Value                                      |
|------------------|--------------------------------------------|
| **Primary**      | `#FF6B35` (Saffron Orange – India flag)    |
| **Secondary**    | `#1B4965` (Deep Navy)                      |
| **Accent**       | `#2EC4B6` (Teal Green – India flag)        |
| **Background**   | `#0A0E17` (Rich Dark) / `#F8F9FA` (Light) |
| **Surface**      | `#141B2D` (Card Dark) / `#FFFFFF` (Light)  |
| **Text Primary** | `#E8E8E8` (Dark mode) / `#1A1A2E` (Light) |
| **Gold Accent**  | `#FFC947` (Highlights)                     |
| **Fonts**        | **Outfit** (headings), **Inter** (body)    |

### Key Pages

#### 1. Landing Page (Home)
- **Hero Section**: Full-screen cinematic hero with auto-rotating background images of iconic Indian destinations. Overlaid with animated search bar and tagline: *"Discover the Soul of India, One State at a Time"*
- **Interactive India Map**: SVG-based clickable map — hover reveals state name + destination count, click navigates to state page
- **Featured States Carousel**: Horizontally scrolling cards with glassmorphism effect
- **Popular Destinations Grid**: 3×2 grid of top destinations with parallax hover effects
- **Categories Section**: 4 category cards (Heritage, Nature, Adventure, Religious) with gradient overlays
- **Statistics Bar**: Animated counters — "36 States & UTs | 500+ Destinations | 100+ Cities"
- **Footer**: Quick links, social links, "Powered by Unified Mentor" badge

#### 2. States Listing Page (`/states`)
- Region-based tab filters (North, South, East, West, Central, Northeast)
- Grid layout with state cards showing thumbnail, name, capital, destination count
- Search within states

#### 3. State Detail Page (`/states/:slug`)
- State hero banner with parallax effect
- Quick facts sidebar (capital, languages, best time, total places)
- Category-wise destination listing
- State gallery section

#### 4. Destination Detail Page (`/states/:stateSlug/:destSlug`)
- Full-width image gallery with lightbox
- Description + historical significance
- Info cards (best time, entry fee, timings)
- Google Maps embed link
- Nearby attractions cards
- Breadcrumb navigation

#### 5. Explore / Search Page (`/explore`)
- Full-featured search with autocomplete
- Multi-filter panel: State, Category, Region
- Results grid with destination cards

#### 6. Admin Panel (`/admin`)
- Dashboard with stats cards
- CRUD tables for States, Destinations, Categories
- Image upload with preview
- Form validation

### Animations & Micro-interactions
- Card hover: subtle lift + shadow expansion
- Scroll-triggered reveal animations (Intersection Observer)
- Map state hover: glow + scale effect
- Search dropdown slide animation
- Loading skeleton screens
- Counter animations on statistics section
- Smooth page scroll transitions

---

## Phased Development Plan

### Phase 1: Project Foundation (Days 1–3)
| Task | Details |
|------|---------|
| Initialize Express.js project | Package.json, dependencies, folder structure |
| Configure Tailwind CSS | tailwind.config.js, custom theme, build pipeline |
| Set up EJS templating | Layouts, partials, view engine |
| Configure PostgreSQL + Sequelize | Connection, models, associations |
| Create all database models | States, Cities, Destinations, Categories, Admins, Images |
| Set up base layout | main.ejs with Navbar + Footer + Google Fonts |
| Create seed data files | JSON files for all 36 states, 100+ destinations |

### Phase 2: Backend API + Seed Data (Days 4–7)
| Task | Details |
|------|---------|
| State API endpoints | CRUD + filters (region, type) |
| Destination API endpoints | CRUD + filters (state, category, search) |
| Category API endpoints | CRUD + destination count |
| Search API | Full-text search across destinations & states |
| Auth endpoints | Admin login/logout with JWT + bcrypt |
| Image upload | Cloudinary integration via Multer |
| Database seeder | Populate all tables with real tourism data |
| Error handling | Global error handler, input validation |

### Phase 3: Public Pages (Days 8–14)
| Task | Details |
|------|---------|
| Home page | Hero, map, featured states, popular destinations, categories, stats |
| States listing page | Grid, region filters, search |
| State detail page | Hero, facts sidebar, destinations grid |
| Destination detail page | Gallery, info cards, nearby places, map |
| Explore/Search page | Search bar, filters, results |
| Category pages | Category listing, destinations by category |
| Gallery page | Masonry image grid with lightbox |
| About page | Project info |
| Client-side JS | Animations, search autocomplete, filters, gallery |

### Phase 4: Admin Panel (Days 15–19)
| Task | Details |
|------|---------|
| Admin login page | JWT-based auth with cookie storage |
| Dashboard | Stats cards, recent destinations |
| States management | CRUD table, add/edit forms |
| Destinations management | Full CRUD, image upload, category tagging |
| Categories management | CRUD with icon/color |
| Route protection | Auth middleware for admin routes |

### Phase 5: Polish & Optimization (Days 20–23)
| Task | Details |
|------|---------|
| Animations & transitions | Scroll reveals, hover effects, counters |
| SEO optimization | Meta tags, JSON-LD, sitemap |
| Image optimization | Lazy loading, Cloudinary transforms |
| Responsive testing | Mobile, tablet, desktop |
| Performance | Lighthouse audit ≥ 90 |
| Error pages | 404, empty states, loading states |

### Phase 6: Deployment & Documentation (Days 24–26)
| Task | Details |
|------|---------|
| Deploy to Render/Railway | Express server + PostgreSQL addon |
| Environment configuration | Production env vars |
| README & documentation | Setup guide, API docs, screenshots |
| Demo recording | Browser recording of full user flow |
| Final testing | End-to-end verification |

---

## API Endpoints Summary

### Public APIs
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/states` | List all states (filters: region, type) |
| GET | `/api/states/:slug` | State detail with destinations |
| GET | `/api/destinations` | List destinations (filters: state, category, search) |
| GET | `/api/destinations/:slug` | Destination detail |
| GET | `/api/destinations/featured` | Featured destinations |
| GET | `/api/categories` | List all categories |
| GET | `/api/categories/:slug` | Category with destinations |
| GET | `/api/search?q=` | Full-text search |
| GET | `/api/stats` | Platform statistics |

### Admin APIs (JWT Protected)
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/login` | Admin login → returns JWT |
| POST | `/api/auth/logout` | Admin logout |
| POST | `/api/states` | Create state |
| PUT | `/api/states/:id` | Update state |
| DELETE | `/api/states/:id` | Delete state |
| POST | `/api/destinations` | Create destination |
| PUT | `/api/destinations/:id` | Update destination |
| DELETE | `/api/destinations/:id` | Delete destination |
| POST | `/api/upload` | Upload image to Cloudinary |

### Page Routes (Server-Rendered HTML)
| Method | Route | Page |
|--------|-------|------|
| GET | `/` | Home page |
| GET | `/states` | States listing |
| GET | `/states/:slug` | State detail |
| GET | `/states/:stateSlug/:destSlug` | Destination detail |
| GET | `/explore` | Search & discover |
| GET | `/categories` | Categories |
| GET | `/categories/:slug` | Category destinations |
| GET | `/gallery` | Photo gallery |
| GET | `/about` | About page |
| GET | `/admin/login` | Admin login |
| GET | `/admin/dashboard` | Admin dashboard |
| GET | `/admin/states` | Manage states |
| GET | `/admin/destinations` | Manage destinations |

---

## Seed Data Coverage

All **28 states + 8 union territories** with:
- **States/UTs**: 36 entries with descriptions, capitals, regions, hero images
- **Categories**: Heritage, Nature, Adventure, Religious
- **Destinations**: 100+ curated tourist places with real descriptions
- **Cities**: 60+ major cities linked to states

### Priority States (10+ destinations each):
1. Rajasthan — Jaipur, Udaipur, Jaisalmer, Jodhpur, Pushkar...
2. Kerala — Alleppey, Munnar, Kochi, Thiruvananthapuram...
3. Uttar Pradesh — Taj Mahal, Varanasi, Lucknow, Mathura...
4. Tamil Nadu — Chennai, Madurai, Ooty, Rameswaram...
5. Karnataka — Hampi, Mysore, Coorg, Bangalore...
6. Himachal Pradesh — Shimla, Manali, Dharamshala, Spiti...
7. Goa — Calangute, Basilica of Bom Jesus, Dudhsagar...
8. Maharashtra — Mumbai, Pune, Ajanta-Ellora, Lonavala...
9. Delhi — Red Fort, India Gate, Qutub Minar, Lotus Temple...
10. Jammu & Kashmir — Dal Lake, Gulmarg, Pahalgam...

---

## SEO Strategy

| Element | Implementation |
|---------|---------------|
| **Title Tags** | Dynamic per page: `"Taj Mahal - Agra | TravelBharat"` |
| **Meta Description** | Auto-generated from destination data |
| **JSON-LD** | `TouristAttraction`, `Place`, `BreadcrumbList` |
| **Sitemap** | Auto-generated `/sitemap.xml` route |
| **robots.txt** | Proper crawler configuration |
| **URL Structure** | Clean: `/states/rajasthan/taj-mahal` |
| **Heading Hierarchy** | Single `<h1>` per page |
| **Semantic HTML** | `<article>`, `<section>`, `<nav>`, `<main>` |

---

## Resolved Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| **PostgreSQL** | Local install (with **Neon** cloud as fallback) | We'll check if you have PostgreSQL locally; if not, we'll use Neon's free tier (instant, zero setup) |
| **Images** | **Unsplash** free high-quality images | Pre-loaded in seed data for all destinations — no manual uploading needed initially. Admin can add more via Cloudinary later |
| **Tailwind CSS** | **Tailwind CDN** (`<script>` tag) | Simplest setup, no build step, works instantly. Custom theme configured inline via `tailwind.config` in the CDN script |
| **Timeline** | **Full build (~4-5 weeks)** | All 6 phases, complete feature set |
| **Interactive Map** | **Full SVG map** (desktop) + **region grid** (mobile) | Best of both worlds — impressive on desktop, functional on mobile |

---

## Verification Plan

### Automated Testing
- `npm run dev` — server starts without errors
- Database seeder runs successfully and populates all tables
- All API endpoints return correct data
- All pages render without errors
- Lighthouse audit targeting score ≥ 90

### Manual Verification
- Browser testing: Chrome, Firefox, Edge
- Responsive: Mobile (375px), Tablet (768px), Desktop (1440px)
- User flow: Home → State → Destination → Back
- Admin flow: Login → CRUD → Logout
- Search and filter functionality
- Image loading and optimization

### Demo Recording
- Browser recording of complete user journey
- Admin panel CRUD demonstration
- Mobile responsive demonstration

